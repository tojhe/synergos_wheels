from flask_executor.executor import Executor


__all__ = ('Executor',)
__version__ = '0.9.3'
